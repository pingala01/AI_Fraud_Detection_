import numpy as np
import pandas as pd

from src import config as C
from src.data_generation import generate_synthetic_transactions
from src.drift import drift_report, psi_numeric
from src.evaluation import choose_threshold, evaluate_scores


def test_synthetic_data_shape_and_fraud_rate():
    df = generate_synthetic_transactions(20_000, 0.008)
    assert len(df) == 20_000
    assert abs(df[C.TARGET].mean() - 0.008) < 0.001
    assert set(C.RAW_COLUMNS) <= set(df.columns)


def test_threshold_respects_fpr_cap():
    rng = np.random.default_rng(0)
    y = (rng.random(20_000) < 0.01).astype(int)
    s = rng.normal(size=20_000) + 2.0 * y
    t = choose_threshold(y, s, 100, 5, 0.05)
    m = evaluate_scores(y, s, t, 100, 5)
    assert m["fpr"] <= 0.05 + 1e-9


def test_psi_detects_shift():
    rng = np.random.default_rng(1)
    a = rng.normal(0, 1, 5000)
    assert psi_numeric(a, rng.normal(0, 1, 5000)) < 0.1
    assert psi_numeric(a, rng.normal(1.5, 1, 5000)) > 0.25


def test_drift_report_flags_drifted_data():
    base = generate_synthetic_transactions(8000, 0.01, seed=1)[C.RAW_COLUMNS]
    same = generate_synthetic_transactions(8000, 0.01, seed=2)[C.RAW_COLUMNS]
    drifted = generate_synthetic_transactions(8000, 0.01, seed=3, drift=True)[C.RAW_COLUMNS]
    assert drift_report(base, same)["overall_status"] == "ok"
    assert drift_report(base, drifted)["overall_status"] == "alert"


def test_quick_training_and_prediction(tmp_path):
    from src.predictor import FraudPredictor
    from src.train import main
    main(["--rows", "20000", "--fraud-rate", "0.02", "--quick", "--model-dir", str(tmp_path / "m"),
          "--report-dir", str(tmp_path / "r"), "--data-dir", str(tmp_path / "d")])
    p = FraudPredictor(tmp_path / "m" / C.MODEL_FILENAME)
    res = p.predict_one({"amount": 900.0, "timestamp": "2026-10-14T02:15:00", "transaction_type": "CASH_OUT",
                         "merchant_category": "crypto", "country": "RU", "device_risk_score": 0.9, "ip_risk_score": 0.8})
    assert 0 <= res["fraud_score"] <= 1 and isinstance(res["is_fraud_flagged"], bool)
    # unseen category must not crash
    p.predict_one({"amount": 5.0, "timestamp": "2026-10-14T12:00:00", "transaction_type": "NEW_TYPE",
                   "merchant_category": "zzz", "country": "ZZ", "device_risk_score": 0.1, "ip_risk_score": 0.1})
