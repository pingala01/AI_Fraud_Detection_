# AWS deployment guide (EC2, S3, Lambda)

**Status: NOT deployed and NOT verified.** These are instructions and configuration prepared locally.
Nothing here was executed against a real AWS account. Expect to adjust details.

## Credentials - never hardcode
- On EC2 and Lambda use an **IAM role** (no keys at all).
- On your own PC run `aws configure` (AWS CLI) or set `AWS_ACCESS_KEY_ID` / `AWS_SECRET_ACCESS_KEY` as environment variables for your session. Never put keys in code, in the ZIP, or in Git.
- Keep `.env` out of Git (already in `.gitignore`).

## Costs you may incur (check current AWS pricing; free-tier eligibility depends on your account)
EC2 instance hours and EBS disk; public IPv4 address; data transfer out; S3 storage and requests; ECR image storage;
Lambda requests, duration (GB-seconds) and optional provisioned concurrency; API Gateway or Function URL traffic;
CloudWatch logs. Prometheus and Grafana run on the same EC2 machine (no separate fee, but they need RAM).
Set an **AWS Budget alert** before you start, and stop/delete resources when finished.

## 1. S3 model storage
1. Create a private bucket (Block all public access = ON, default encryption ON).
2. Train locally: `python -m src.train`.
3. Set `MODEL_S3_BUCKET=<your-bucket>` and upload: `python -m src.storage upload`
   (uploads `fraud_model.joblib` and `reference_sample.csv` under `fraud-model/`, encrypted with SSE-S3).
4. Minimal IAM policy for the API/Lambda role (read-only), replace the bucket name:
```json
{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":["s3:GetObject"],"Resource":"arn:aws:s3:::YOUR-BUCKET/fraud-model/*"}]}
```
The uploader needs `s3:PutObject` on the same prefix.

**Important:** the model file is a Python pickle. Only load files you trust, and train with the same library versions
that will load it (train inside the Docker image: `docker compose run --rm trainer`).

## 2. EC2 (API + dashboard + Prometheus + Grafana via Docker Compose)
1. Launch an EC2 instance (e.g. 2 vCPU / 4 GB RAM or larger), Ubuntu or Amazon Linux, with an IAM role allowing S3 read.
2. Security group: allow SSH (22) from **your IP only**; open 8000/8501/3000/9090 only to trusted IPs, or put the API behind a load balancer/HTTPS. Do not expose Prometheus/Grafana publicly.
3. Install Docker + the Compose plugin, copy the project folder (git clone or `scp`).
4. `cp .env.example .env` and set `API_KEY`, `MODEL_S3_BUCKET`, `AWS_REGION`, `GRAFANA_ADMIN_PASSWORD`.
5. `docker compose run --rm trainer` (or download the model from S3 on start: the API does this automatically when `MODEL_S3_BUCKET` is set and no local model exists).
6. `docker compose up -d --build` then check `curl http://localhost:8000/health`.
7. Measure latency on the instance: `python scripts/benchmark_api.py`.

## 3. Lambda (serverless inference, container image)
1. Create an ECR repository; build and push: `docker build -f Dockerfile.lambda -t fraud-lambda .` then tag/push per the ECR "View push commands" page.
2. Create a Lambda function **from the container image**. Suggested start: 1024-2048 MB memory, 30 s timeout.
3. Environment variables: `MODEL_S3_BUCKET`, `MODEL_S3_PREFIX` (optional), `MODEL_DIR=/tmp/models`.
4. Execution role: basic Lambda logging + the S3 read policy above.
5. Expose with a Function URL (with IAM auth) or API Gateway. Test event:
```json
{"amount": 950.0, "timestamp": "2026-10-14T02:15:00", "transaction_type": "CASH_OUT", "merchant_category": "crypto", "country": "RU", "device_risk_score": 0.85, "ip_risk_score": 0.78}
```
6. **Latency caveat:** the first request after idle (cold start) downloads the model from S3 and imports scikit-learn/XGBoost, which can take seconds - far above 100 ms. Warm invocations are much faster. For a strict latency SLA consider provisioned concurrency or the EC2 service. Measure it yourself; no Lambda figures are claimed here.
7. The Lambda image has no SHAP (kept small). Explanations come from the API/dashboard.
8. Possible issue: if `import xgboost` fails with a missing `libgomp`, install that OS package in `Dockerfile.lambda`.

## Compliance note (PSD2 / PCI DSS)
SHAP explanations help a reviewer see which factors drove a score. They do not by themselves make the system PSD2 or PCI DSS compliant.
Real compliance also needs strong customer authentication flows, access control, audit logging, data protection, and legal review.
This project stores no card numbers; never log full card data.
