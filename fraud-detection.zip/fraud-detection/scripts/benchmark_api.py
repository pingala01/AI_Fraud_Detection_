"""Measure end-to-end HTTP latency of the running API (sequential requests).
Usage: python scripts\\benchmark_api.py --n 300"""
import argparse
import json
import os
import time
from pathlib import Path

import numpy as np
import requests

ap = argparse.ArgumentParser()
ap.add_argument("--n", type=int, default=300)
a = ap.parse_args()
URL = os.getenv("API_URL", "http://127.0.0.1:8000")
HEADERS = {"X-API-Key": os.environ["API_KEY"]} if os.getenv("API_KEY") else {}
root = Path(__file__).resolve().parent.parent
payload = json.loads((root / "samples" / "suspicious_transaction.json").read_text(encoding="utf-8"))

s = requests.Session()
for _ in range(20):
    s.post(f"{URL}/predict", json=payload, headers=HEADERS)
rt, srv = [], []
for _ in range(a.n):
    t = time.perf_counter()
    r = s.post(f"{URL}/predict", json=payload, headers=HEADERS)
    rt.append((time.perf_counter() - t) * 1000)
    srv.append(r.json()["latency_ms"])
res = {"n": a.n, "round_trip_ms": {p: float(np.percentile(rt, q)) for p, q in (("p50", 50), ("p95", 95), ("p99", 99))},
       "server_scoring_ms": {p: float(np.percentile(srv, q)) for p, q in (("p50", 50), ("p95", 95), ("p99", 99))},
       "note": "client and server on the same machine; real networks add latency"}
print(json.dumps(res, indent=2))
(root / "reports").mkdir(exist_ok=True)
(root / "reports" / "api_latency.json").write_text(json.dumps(res, indent=2), encoding="utf-8")
print("Target: < 100 ms. Met (round-trip p99):", res["round_trip_ms"]["p99"] < 100)
