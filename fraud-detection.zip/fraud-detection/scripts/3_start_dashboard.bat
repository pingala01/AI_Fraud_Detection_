@echo off
cd /d "%~dp0.."
call venv\Scripts\activate.bat
streamlit run app\dashboard.py
pause
