"""Retrain when drift is detected in a new LABELLED dataset (schedule with Windows Task Scheduler or cron).
Usage: python scripts\\retrain_if_drift.py --new-data data\\new_transactions.csv [--force]
The old model is archived first. Review the new reports\\RESULTS.md before relying on the new model,
then call POST /reload on the API (or restart it)."""
import argparse
import shutil
import sys
from datetime import datetime
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src import config as C  # noqa: E402
from src.drift import drift_report  # noqa: E402
from src.train import main as train_main  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--new-data", required=True)
ap.add_argument("--force", action="store_true")
a = ap.parse_args()

new = pd.read_csv(a.new_data)
ref = pd.read_csv(C.REFERENCE_PATH)
rep = drift_report(ref, new[C.RAW_COLUMNS])
print(f"Max PSI = {rep['max_psi']:.3f} ({rep['overall_status']}); drifted features: {rep['drifted_features']}")
if rep["max_psi"] >= C.PSI_ALERT or a.force:
    if C.MODEL_PATH.exists():
        arch = C.MODEL_DIR / "archive"
        arch.mkdir(exist_ok=True)
        shutil.copy(C.MODEL_PATH, arch / f"fraud_model_{datetime.now():%Y%m%d_%H%M%S}.joblib")
    train_main(["--data", a.new_data])
else:
    print("No significant drift - model not retrained.")
