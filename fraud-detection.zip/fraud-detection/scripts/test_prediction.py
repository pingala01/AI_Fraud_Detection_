"""Send two sample transactions to the running API.  Usage: python scripts\\test_prediction.py"""
import json
import os
import sys
from pathlib import Path

import requests

URL = os.getenv("API_URL", "http://127.0.0.1:8000")
HEADERS = {"X-API-Key": os.environ["API_KEY"]} if os.getenv("API_KEY") else {}
SAMPLES = Path(__file__).resolve().parent.parent / "samples"

for name in ("legit_transaction.json", "suspicious_transaction.json"):
    payload = json.loads((SAMPLES / name).read_text(encoding="utf-8"))
    try:
        r = requests.post(f"{URL}/predict", params={"explain": "true"}, json=payload, headers=HEADERS, timeout=10)
    except requests.ConnectionError:
        sys.exit("Cannot reach the API. Start it first:  uvicorn api.main:app --port 8000")
    print(f"\n=== {name} -> HTTP {r.status_code}")
    print(json.dumps(r.json(), indent=2))
