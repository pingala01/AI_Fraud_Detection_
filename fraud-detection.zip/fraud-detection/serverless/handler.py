"""AWS Lambda handler (container-image deployment). See docs/AWS_DEPLOYMENT.md.
Environment variables: MODEL_S3_BUCKET, MODEL_S3_PREFIX (optional), MODEL_DIR=/tmp/models.
Credentials come from the Lambda execution role - nothing is hardcoded."""
import json
import os

from src import config as C
from src.predictor import FraudPredictor

_predictor = None
REQUIRED = ["amount", "timestamp", "transaction_type", "merchant_category", "country",
            "device_risk_score", "ip_risk_score"]


def _load():
    global _predictor
    if _predictor is None:
        if not C.MODEL_PATH.exists():
            from src.storage import download_artifacts
            download_artifacts()
        _predictor = FraudPredictor(C.MODEL_PATH)
    return _predictor


def _response(code, body):
    return {"statusCode": code, "headers": {"Content-Type": "application/json"}, "body": json.dumps(body)}


def lambda_handler(event, context):
    try:
        body = event.get("body") if isinstance(event, dict) and "body" in event else event
        payload = json.loads(body) if isinstance(body, str) else body
        missing = [k for k in REQUIRED if k not in payload]
        if missing:
            return _response(400, {"error": f"missing fields: {missing}"})
        record = {k: payload[k] for k in REQUIRED}
        result = _load().predict_one(record)
        result.pop("raw_score", None)
        result["transaction_id"] = payload.get("transaction_id")
        return _response(200, result)
    except Exception as exc:  # noqa: BLE001
        return _response(500, {"error": str(exc)})
