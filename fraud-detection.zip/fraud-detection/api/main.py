"""FastAPI real-time fraud scoring service.

Start (from the project folder):  uvicorn api.main:app --host 127.0.0.1 --port 8000
Interactive docs:                 http://127.0.0.1:8000/docs
Metrics for Prometheus:           http://127.0.0.1:8000/metrics
"""
import hmac
import logging
import os
import threading
import time
from collections import deque
from contextlib import asynccontextmanager
from datetime import datetime
from typing import List, Optional

import pandas as pd
from fastapi import Depends, FastAPI, Header, HTTPException, Query, Response
from prometheus_client import CONTENT_TYPE_LATEST, Counter, Gauge, Histogram, generate_latest
from pydantic import BaseModel, ConfigDict, Field

from src import config as C
from src.drift import drift_report
from src.predictor import FraudPredictor

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("fraud-api")

PREDICTIONS = Counter("fraud_predictions_total", "Predictions made", ["decision"])
ERRORS = Counter("fraud_prediction_errors_total", "Failed prediction requests")
LATENCY = Histogram("fraud_prediction_latency_seconds", "Model scoring latency",
                    buckets=(0.001, 0.0025, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0))
SCORES = Histogram("fraud_risk_score", "Distribution of risk scores",
                   buckets=(0.01, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0))
FEATURE_PSI = Gauge("fraud_feature_drift_psi", "PSI of each monitored feature vs training reference", ["feature"])
MAX_PSI = Gauge("fraud_drift_max_psi", "Largest feature PSI")
MODEL_LOADED = Gauge("fraud_model_loaded", "1 if a model is loaded")


class State:
    predictor: Optional[FraudPredictor] = None
    reference: Optional[pd.DataFrame] = None
    buffer = deque(maxlen=C.DRIFT_WINDOW)
    lock = threading.Lock()
    since_check = 0
    checking = False


STATE = State()


def load_model(force_download=False):
    bucket = os.getenv("MODEL_S3_BUCKET")
    if bucket and (force_download or not C.MODEL_PATH.exists()):
        from src.storage import download_artifacts
        download_artifacts()
    if not C.MODEL_PATH.exists():
        log.warning("No model at %s - train one with: python -m src.train", C.MODEL_PATH)
        STATE.predictor = None
        MODEL_LOADED.set(0)
        return False
    STATE.predictor = FraudPredictor(C.MODEL_PATH)
    STATE.reference = pd.read_csv(C.REFERENCE_PATH) if C.REFERENCE_PATH.exists() else None
    MODEL_LOADED.set(1)
    log.info("Loaded model '%s'", STATE.predictor.name)
    return True


@asynccontextmanager
async def lifespan(app):
    try:
        load_model()
    except Exception:
        log.exception("Model loading failed")
    yield


app = FastAPI(title="Bank Fraud Detection API", version="1.0.0", lifespan=lifespan)


def require_api_key(x_api_key: Optional[str] = Header(default=None)):
    expected = os.getenv("API_KEY")
    if expected and not hmac.compare_digest(x_api_key or "", expected):
        raise HTTPException(status_code=401, detail="Invalid or missing X-API-Key header")


class Transaction(BaseModel):
    model_config = ConfigDict(json_schema_extra={"example": {
        "transaction_id": "TX-1001", "amount": 950.0, "timestamp": "2026-10-14T02:15:00",
        "transaction_type": "CASH_OUT", "merchant_category": "crypto", "country": "RU",
        "device_risk_score": 0.85, "ip_risk_score": 0.78}})
    transaction_id: Optional[str] = None
    amount: float = Field(..., gt=0)
    timestamp: datetime
    transaction_type: str = Field(..., min_length=1, max_length=40)
    merchant_category: str = Field(..., min_length=1, max_length=40)
    country: str = Field(..., min_length=2, max_length=3)
    device_risk_score: float = Field(..., ge=0, le=1)
    ip_risk_score: float = Field(..., ge=0, le=1)


class Contribution(BaseModel):
    feature: str
    display: str
    shap_value: float
    direction: str


class Explanation(BaseModel):
    method: str
    units: str
    base_value: float
    contributions: List[Contribution]


class PredictionResponse(BaseModel):
    transaction_id: Optional[str]
    fraud_score: float
    is_fraud_flagged: bool
    risk_level: str
    threshold: float
    model_name: str
    score_type: str
    latency_ms: float
    explanation: Optional[Explanation] = None


def _drift_worker():
    try:
        with STATE.lock:
            rows = list(STATE.buffer)
        rep = drift_report(STATE.reference, pd.DataFrame(rows))
        for name, v in rep["features"].items():
            FEATURE_PSI.labels(feature=name).set(v["psi"])
        MAX_PSI.set(rep["max_psi"])
    except Exception:
        log.exception("Drift check failed")
    finally:
        STATE.checking = False


def _record_for_drift(record, raw_score):
    with STATE.lock:
        STATE.buffer.append({**record, "score": raw_score})
        STATE.since_check += 1
        due = (STATE.since_check >= C.DRIFT_CHECK_EVERY and len(STATE.buffer) >= C.DRIFT_MIN_ROWS
               and STATE.reference is not None and not STATE.checking)
        if due:
            STATE.since_check = 0
            STATE.checking = True
    if due:
        threading.Thread(target=_drift_worker, daemon=True).start()


@app.post("/predict", response_model=PredictionResponse, dependencies=[Depends(require_api_key)])
def predict(tx: Transaction, explain: bool = Query(False, description="Include SHAP explanation"),
            top_k: int = Query(5, ge=1, le=15)):
    pred = STATE.predictor
    if pred is None:
        raise HTTPException(503, "Model not loaded. Train one first: python -m src.train")
    record = tx.model_dump(exclude={"transaction_id"})
    record["timestamp"] = tx.timestamp.isoformat()
    try:
        t0 = time.perf_counter()
        result = pred.predict_one(record)
        elapsed = time.perf_counter() - t0
    except Exception:
        ERRORS.inc()
        log.exception("Prediction failed")
        raise HTTPException(500, "Prediction failed")
    LATENCY.observe(elapsed)
    SCORES.observe(result["fraud_score"])
    PREDICTIONS.labels(decision="flagged" if result["is_fraud_flagged"] else "allowed").inc()
    _record_for_drift(record, result.pop("raw_score"))
    explanation = None
    if explain:
        try:
            explanation = pred.explain_one(record, top_k)
        except Exception:
            log.exception("Explanation failed (is the 'shap' package installed?)")
    return PredictionResponse(transaction_id=tx.transaction_id, latency_ms=round(elapsed * 1000, 3),
                              explanation=explanation, **result)


@app.get("/health")
def health():
    return {"status": "ok", "model_loaded": STATE.predictor is not None}


@app.get("/model-info")
def model_info():
    p = STATE.predictor
    if p is None:
        raise HTTPException(503, "Model not loaded")
    return {"model_name": p.name, "threshold": p.threshold, "trained_at": p.trained_at,
            "score_type": p.kind, "features": p.feature_names}


@app.get("/drift", dependencies=[Depends(require_api_key)])
def drift():
    if STATE.reference is None:
        raise HTTPException(503, "No reference sample available")
    with STATE.lock:
        rows = list(STATE.buffer)
    if len(rows) < C.DRIFT_MIN_ROWS:
        return {"status": "insufficient_data", "n_current": len(rows), "needed": C.DRIFT_MIN_ROWS}
    return drift_report(STATE.reference, pd.DataFrame(rows))


@app.post("/reload", dependencies=[Depends(require_api_key)])
def reload_model():
    """Reload the model from disk (or S3 when MODEL_S3_BUCKET is set) without restarting."""
    ok = load_model(force_download=True)
    if not ok:
        raise HTTPException(503, "Model files not found")
    return {"status": "reloaded", "model_name": STATE.predictor.name}


@app.get("/metrics")
def metrics():
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)
